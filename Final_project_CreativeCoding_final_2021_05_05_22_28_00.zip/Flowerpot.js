class Flowerpot {
  constructor() {
    this.rimW = 5;
    this.rimH = 5 + windowHeight / 17;

    this.potW = windowWidth / 2 + 10;
    this.potH = 10 + windowHeight / 3 - this.rimH;
    this.p1 = (windowWidth - this.potW) / 2;
    this.p2 = windowHeight - this.potH;
    this.p3 = this.potW;
    this.p4 = this.potH;
    this.potAngle = windowHeight / 100 + windowWidth / 30;


  }

  display() {
    //wite pot for plant
    strokeWeight(4);
    stroke('#B2DFE9');
    fill(255, 255, 255, 80);


    quad(this.p1, this.p2, this.p1 + this.p3, this.p2, this.p1 + this.p3 - this.potAngle, windowHeight, this.p1 + this.potAngle, windowHeight);
    //pot rim color
    quad(this.p1 - this.rimW, this.p2 + 1, this.p1 + this.p3 + this.rimW, this.p2 + 1, this.p1 + this.p3 + this.rimW, this.p2 - this.rimH, this.p1 - this.rimW, this.p2 - this.rimH);
    //pot rim white
    fill(255, 255, 255, 90);
    quad(this.p1 - this.rimW, this.p2, this.p1 + this.p3 + this.rimW, this.p2, this.p1 + this.p3 + this.rimW, this.p2 - this.rimH, this.p1 - this.rimW, this.p2 - this.rimH);

  }

  update() {

  }
  drawWaterFull() {
    let level1Full = this.p2;
    let level2Full = this.p2 + 25;
  

    fill(100, 200, 255, 200);
    beginShape();
    let xoff = 0; // Option #1: 2D Noise
    // Iterate over horizontal pixels
    for (let x = this.potW/2; x <= this.potW *1.49; x += 10) {
       let y = map(noise(xoff, yoff), 0, 1, level1Full, level2Full);
        // Set the vertex
        vertex(x, y);
        // Increment x dimension for noise
        xoff += 0.09;
    }
    // increment y dimension for noise
    yoff += 0.06;
    //bottom vertex points starting at windowheight
    vertex(this.potW *1.37, windowHeight);
    vertex(this.potW/1.6, windowHeight);
    endShape(CLOSE);
  }
   drawWaterHalf(){
      let level1Half = this.p2 /0.9;
      let level2Half = (this.p2 + 25) /0.9;
     fill(100, 200, 255, 220);

       beginShape();
      let xoff = 0; // Option #1: 2D Noise
      // Iterate over horizontal pixels
      for (let x = this.potW / 2; x <= this.potW * 1.49; x += 10) {
        let y = map(noise(xoff, yoff), 0, 1, level1Half, level2Half);
        // Set the vertex
        vertex(x, y);
        // Increment x dimension for noise
        xoff += 0.09;
      }
      // increment y dimension for noise
      yoff += 0.06;
      //bottom vertex points starting at windowheight
      vertex(this.potW * 1.37, windowHeight);
      vertex(this.potW / 1.6, windowHeight);
      endShape(CLOSE);
    }
  
   drawWaterEmpty(){
      let level1Empty = this.p2 /0.8;
      let level2Empty = (this.p2 + 25) /0.8;
         fill(100, 200, 255, 220);

       beginShape();
      let xoff = 0; // Option #1: 2D Noise
      // Iterate over horizontal pixels
      for (let x = this.potW / 1.9; x <= this.potW * 1.45; x += 10) {
        let y = map(noise(xoff, yoff), 0, 1, level1Empty, level2Empty);
        // Set the vertex
        vertex(x, y);
        // Increment x dimension for noise
        xoff += 0.09;
      }
      // increment y dimension for noise
      yoff += 0.06;
      //bottom vertex points starting at windowheight
      vertex(this.potW * 1.35, windowHeight);
      vertex(this.potW / 1.6, windowHeight);
      endShape(CLOSE);
    }
  
  waterMeasurement(){
    
  }
}