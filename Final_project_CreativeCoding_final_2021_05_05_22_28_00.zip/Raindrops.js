class Raindrops{
   constructor() {
    this.x = random(width);
    this.y = random(0,height/3);
     this.xposition = random()
    this.hue = random(360);
    this.size; 
  }

  update() {
    this.x += random(-5, 5);
    this.y += random(-5, 6);
  }

  display(humidity) {
    stroke(0, 20);
    if(humidity < 50){
    //  this.size = humidity*1.4;
      this.size = humidity/humidity;

      fill(56, 169, 255, humidity*1.2);
    }
    else if(humidity >=50 && humidity <74){
      //this.size = humidity*1.9;
      this.size = humidity/28;
      fill(64, 97, 230, humidity*2.6);
    }
    else if(humidity >=75){
      //this.size = humidity*2.3;
      this.size = humidity/20;

      fill(56, 169, 255, humidity*2.8);
    }
  
    push();
    translate(this.x, this.y);
    noStroke();
    scale(this.size);
    let xposition = 50 ;
    let yposition = 0;
    triangle(xposition-10,yposition,xposition+10,yposition,xposition,yposition-40)
    ellipse(xposition,yposition,20,20);
    pop();

  
 //  circle(this.x, this.y, this.size);
  }

}