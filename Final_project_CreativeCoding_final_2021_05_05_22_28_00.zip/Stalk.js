class Stalk{
  constructor(){
    this.x = random(width/1.5, width/3); 
    this.y = height; 
    this.sizeX = random(-150, 150);
    this.sizeY = random(350, 650); 
    this.stroke = random(0.5,12);
    this.leaves = []; 
    for(let i = 0; i < 3; i++){
          this.leaves.push(new Leaf(random(this.x, this.x + this.sizeX), random(this.y - this.sizeY, this.y -this.sizeY/3 *2))); 
    }
    
  }
  
  update(){
    this.x += random(-1,1);
     for(let i = 0; i < this.leaves.length; i++){
        this.leaves[i].update(); 
  }
  }
  
  display(){
  push();
  stroke('pink');
  strokeWeight(this.stroke);
  curve(this.x - 100, this.y, this.x, this.y, this.x + this.sizeX , this.y -  this.sizeY, this.x + 200, this.y);
  pop();
  for(let i = 0; i < this.leaves.length; i++){
    this.leaves[i].display(); 
  }
   
  }
}