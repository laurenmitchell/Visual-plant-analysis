
class Leaf{
  //is there a transform sign i can use to increase the size of ellipse without ruining the shape? 
  constructor(xPos, yPos){
    this.x = xPos; 
    this.y = yPos; 
    this.angle =random(0,360);
    this.size =random(0.5, 2.2);
    this.maxSize = random(0.5, 1.3);
    //this.maxSize = random(2.2,2.8);
    this.pulseSpeed = random(1, 12);


  }
  
 update(){
  this.x += random(-1,1);
  this.y +=random(-1,1);
  // this.size += random(0.001,0.005);
   this.size = this.maxSize * sin(frameCount *this.pulseSpeed) +0.5;   
  }

  display(){
    
    fill(random(235,250), random(200,220), random(240,250));
    push();
    translate(this.x, this.y);
    rotate(this.angle);
   // scale(3);
    scale(this.size);
    strokeWeight(2);
    stroke('pink');
    fill(random(70,90),random(160,170),random(90,110),random(220,260));
    //ellipse(0, 0, this.size, this.size);

    ellipse(0, 0, 13*3, 26*3);
    line(0,-3*3,0,13*3);
    strokeWeight(5);
    stroke('green');
    line(0,12*3,0,18*3);
    pop();
  }

  
}