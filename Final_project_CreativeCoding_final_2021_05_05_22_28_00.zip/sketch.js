//used datetime 
//have a button to click that updates last time the plant was watered 
//display how many days it has been since last watering 
//water jug emptying based on soil moisture 
//have plant be pulsing/growing over time 

let x, y, waterWidth,waterHeight;
let empty, full;
let yoff = 0;

let moisture = []; 
let humidity = [];
let temperature = [];
let raindrops = []
// Declare a "SerialPort" object
let serial;
let latestData = "waiting for data";  // you'll use this to write incoming data to the canvas
let soilData = [];
let stalks = []; 
let average; 
let currMoisture;
let currHumidity; 
let currTemp;


function setup() {
  createCanvas(windowWidth, windowHeight);
  frameRate(5);
  for(i=0; i<20; i++){
     raindrops.push(new Raindrops());
  }
 
  pot = new Flowerpot();
  for(i = 0; i< 17; i++){
    stalks.push(new Stalk()); 
  }
  //stalk = new Stalk(); 
  cup = new Cup(createVector(width/5, height/2), 550);
  
  // Instantiate our SerialPort object
  serial = new p5.SerialPort();

  // Get a list the ports available
  // You should have a callback defined to see the results
  serial.list();

  // Assuming our Arduino is connected, let's open the connection to it
  // Change this to the name of your arduino's serial port
  serial.open("/dev/tty.usbmodem1301");

  // Here are the callbacks that you can register
  // When we connect to the underlying server
  serial.on('connected', serverConnected);

  // When we get a list of serial ports that are available
  serial.on('list', gotList);
  // OR
  //serial.onList(gotList);

  // When we some data from the serial port
  serial.on('data', gotData);
  // OR
  //serial.onData(gotData);

  // When or if we get an error
  serial.on('error', gotError);
  // OR
  //serial.onError(gotError);

  // When our serial port is opened and ready for read/write
  serial.on('open', gotOpen);
  // OR
  //serial.onOpen(gotOpen);

  serial.on('close', gotClose);

  // Callback to get the raw data, as it comes in for handling yourself
  //serial.on('rawdata', gotRawData);
  // OR
  //serial.onRawData(gotRawData);

}
// We are connected and ready to go
function serverConnected() {
  print("Connected to Server");
}

// Got the list of ports
function gotList(thelist) {
  print("List of Serial Ports:");
  // theList is an array of their names
  for (let i = 0; i < thelist.length; i++) {
    // Display in the console
    print(i + " " + thelist[i]);
  }
}

// Connected to our serial device
function gotOpen() {
  print("Serial Port is Open");
}

function gotClose(){
    print("Serial Port is Closed");
    latestData = "Serial Port is Closed";
}

// Ut oh, here is an error, let's log it
function gotError(theerror) {
  print(theerror);
}

// There is data available to work with from the serial port
function gotData() {

  let currentString = serial.readLine();  // read the incoming string
  trim(currentString);                    // remove any trailing whitespace
  if (!currentString) return;             // if the string is empty, do no more
 // console.log(currentString);             // print the string
  latestData = currentString;  // save it for the draw method
  data = latestData.split(',');
  //console.log(data);
  //collecting moisture data 
  if (moisture.length <= 2){
    moisture.push(int(data[0])); 
   // console.log(moisture);
    if(moisture.length == 2){
      //  console.log(getAverage(moisture)); 
        currMoisture= (getAverage(moisture));
        
      }
       
  }
  else if(moisture.length >2){
    moisture = [];
  }
  // if(currMoisture <100){
  //         fill('white');
  //         rect(width/2, height/2, 100, 100);
  //         }  
 // console.log(currMoisture);
  
    
  //collecting humidity data 
   if(humidity.length <= 2){
    humidity.push(int(data[1])); 
   // console.log(moisture);
    if(humidity.length == 2){
       // console.log(getAverage(humidity)); 
        currHumidity= (getAverage(humidity));
        
      }  
  }
  else if(humidity.length >2){
    humidity = [];
  }
  // if(currMoisture <100){
  //         fill('white');
  //         rect(width/2, height/2, 100, 100);
  //         }  
 // console.log(currHumidity);
  
  
   currTemp = data[2];
}

function detectWaterIntake(moistureData){
  //if the last two averages have an increase > 50; then detect a water intake and mark the time stamp 
  
}


//if moisture array is > 60 elements,then reset the water height based on average range and set moisture array back to empty
//when moisture level spikes then call new date time because indicates last water 


// We got raw from the serial port
function gotRawData(thedata) {
  print("gotRawData" + thedata);
}

function getAverage(data){
  let sum = 0;
  for(var i = 0; i < data.length; i++) {
    sum += data[i];
  }
  average = sum / data.length;
  return average; 
}




function curr_date()
{
  fill("pink");
  //textFont(clockFont);
  noStroke();
  textAlign(LEFT, TOP);
  textSize(width/28);
  let date = new Date();
  date = date.toDateString().slice(4);
  let m = month(); 
  let d = day(); 
  let Hour = hour();
  let min = minute();
  let secs = second()
  let noon = Hour >= 12? " PM" : " AM"
  if(min < 10)
    min = "0"+min
  Hour%=12
  text(date + " \n " + Hour+":"+min+":"+secs+noon, width/1.3, height/1.2);
  return date + Hour+":"+min+":"+secs+noon;

}
function lastWater(){
  fill('purple');
  textSize(width/35);
  // textAlign(TOP);
 // text( "You last watered on:", width/1.7, height/6.5);
 // text("You need to water again in " + " days", width/1.7, height/5);
}



function drawTemp(currTemp){
  push();
  //translate(width/12, height/1.7);
     //outline of thermometer
  noFill();
  rect(40, 50, 20, 250)

  //bottom of thermometer
  fill(227, 66, 66,250);
  ellipse(50, 300, 50, 50);
 
  stroke(227, 50, 56,150)
  strokeWeight(16)
 
   if (currTemp >50 && currTemp <75) {
    line(50, 300, 50, 150)
  } else if (currTemp <=50) {
    line(50, 300, 50, 250)
  }
    else if(currTemp >=75){
       line(50, 300, 50, 70);
    }
   else {
   // console.log("no line drawn")
  }
  
  textSize(16);
  noStroke();
  fill('white');
  
  if (currTemp <=50) {
    text("It is too cold in your enviornment", 75, 250);
    text(currTemp,  75, 265);
  } else if (currTemp >=75) {
    text("It is too warm in your enviorment", 75, 70);
    text(currTemp,  75, 85);
  } else if (currTemp >50 && currTemp <75) {
    text("" +currTemp+ " degrees F. ", 77, 150);
    rect(55, 149, 20,5);
    
    // text(currTemp,  75, 165);
  } 
   pop();

}

function drawHumidity(currHum){
//  background(220)
  //make raindrops or bubbles and as humidity grows, increase size of bubbles 
  push();
  translate(width/1.3, height/50);
  scale(0.5);
  fill(123,120,170);
  rectMode(CENTER);
  rect(200,200,250,250,30)
  w=map(currHum,0,100,0,360);
  angleMode(DEGREES);
  noStroke()
  fill(129, 44, 199);
  arc(200,200,100,100,0,w);
  fill(255);
  ellipse(200,200,80,80);
  text(CENTER);
  text("Humidity: "+ currHum + "%",width/10, height/10);
  pop();
}



function draw() {
 // background('#0087AA'); //medium blue
  background(139, 133, 212);

    // push();
    // translate(random(width), random(height));
    // noStroke();
    // scale(this.size);
    // fill('black');
    // let xposition = 50 *2.5;
    // let yposition = 100*2.5;
    // triangle(xposition-10,yposition,xposition+10,yposition,xposition,yposition-40)
    // ellipse(xposition,yposition,20,20);
    // pop();

  curr_date();
  lastWater();
  for(let i = 0; i<raindrops.length; i++){
    let rain = raindrops[i];
  
    rain.update();
    rain.display(currHumidity);
  }
  noFill();
  for(let i = 0; i <stalks.length; i++){
    let stalk = stalks[i]; 
    stalk.display();
    stalk.update();
  }

   pot.display();
  //pot.drawWater();
  //console.log(currMoisture);
  // pot.drawWater(currMoisture);
    drawTemp(currTemp); 
    drawHumidity(currHumidity);

  if(currMoisture >100){
    //waterTest(currMoisture);
    pot.drawWaterFull();
  }
  else if(currMoisture <100 && currMoisture >=50){
    pot.drawWaterHalf();
  }
  else if(currMoisture <50){
    pot.drawWaterEmpty(67);
  }
  
  
 
}


